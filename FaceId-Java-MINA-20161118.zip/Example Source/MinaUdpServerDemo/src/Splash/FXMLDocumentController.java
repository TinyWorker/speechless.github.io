/* ----------------------------------------------------------
 * 文件名称：FXMLDocumentController.java
 * 
 * 作者：秦建辉
 * 
 * 微信：splashcn
 * 
 * 博客：http://www.firstsolver.com/wordpress/
 * 
 * 开发环境：
 *      NetBeans 8.1
 *      JDK 8u102
 *      
 * 版本历史：
 *      V1.1    2016年08月10日
 *              SDK更新
 *
 *      V1.0    2015年12月11日
 *              验证心跳包服务器端
------------------------------------------------------------ */
package Splash;

import Com.FirstSolver.Splash.FaceIdProtocolCodecFactory;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioDatagramAcceptor;

public class FXMLDocumentController extends IoHandlerAdapter implements Initializable {
    private final String DeviceCharset = "GBK";
    
    private boolean IsServerRunning = false;
    
    public IoAcceptor mUdpServer = null;
	
    @FXML
    private ComboBox comboBoxServerIP;
    
    @FXML
    private TextField textFieldServerPort;

    @FXML
    private TextArea textAreaAnswer;
    
    @FXML
    private Button buttonStartListener;
    
    @FXML
    private CheckBox checkBoxTask;
            
    @FXML
    private void handleButtonClearAction(ActionEvent event) {
        textAreaAnswer.clear();
    }
    
    @FXML
    private void handleButtonStartListenerAction(ActionEvent event) throws IOException, Exception {
        if(IsServerRunning)
        {
            if(mUdpServer != null)
            {
                mUdpServer.dispose(true);
                mUdpServer = null;
            }
            IsServerRunning = false;
            buttonStartListener.setText("开始侦听");
        }
        else
        {
            // 创建侦听服务器
            mUdpServer = new NioDatagramAcceptor();
            mUdpServer.getFilterChain().addLast("codec", new ProtocolCodecFilter(new FaceIdProtocolCodecFactory(DeviceCharset, false, false)));
            mUdpServer.setHandler(this);
            mUdpServer.bind(new InetSocketAddress(InetAddress.getByName(comboBoxServerIP.getValue().toString()), Integer.parseInt(textFieldServerPort.getText())));
			
            IsServerRunning = true;
            buttonStartListener.setText("停止侦听");
        }
    }
    
    @Override
    public void messageReceived(IoSession session, Object message) throws Exception {
        // 显示消息内容
        String Answer = message.toString();
        textAreaAnswer.appendText(Answer + "\r\n");
        
        // 判断是否有命令下发
        if (checkBoxTask.isSelected())
        {   // 通知设备有命令要发送
            session.write("PostRequest()");
        }        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // 设置服务器地址
        try
        {
            List<String> IPList = new LinkedList<>();
            Enumeration<NetworkInterface> InterfaceList = NetworkInterface.getNetworkInterfaces();
            while (InterfaceList.hasMoreElements())
            { 
                NetworkInterface iFace = InterfaceList.nextElement();
                if(iFace.isLoopback() || iFace.isVirtual() || iFace.isPointToPoint() || !iFace.isUp()) continue;
                                
                Enumeration<InetAddress> AddrList = iFace.getInetAddresses(); 
                while (AddrList.hasMoreElements())
                { 
                    InetAddress address = AddrList.nextElement(); 
                    if (address instanceof Inet4Address)
                    {
                        IPList.add(address.getHostAddress());                
                    }
                } 
            }
            
            if (!IPList.isEmpty()) 
            {
                comboBoxServerIP.setItems(FXCollections.observableList(IPList));
                comboBoxServerIP.getSelectionModel().selectFirst();
            }
        }
        catch (SocketException ex)
        {
            // 异常处理
        }
    }	
}
