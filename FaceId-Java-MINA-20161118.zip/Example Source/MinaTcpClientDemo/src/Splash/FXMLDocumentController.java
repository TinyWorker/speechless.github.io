/* ----------------------------------------------------------
 * 文件名称：FXMLDocumentController.java
 * 
 * 作者：秦建辉
 * 
 * 微信：splashcn
 * 
 * 博客：http://www.firstsolver.com/wordpress/
 * 
 * 开发环境：
 *      NetBeans 8.1
 *      JDK 8u102
 *      
 * 版本历史：
 *      V1.1    2016年08月10日
 *              SDK更新
 *
 *      V1.0    2015年12月10日
 *              验证客户端
------------------------------------------------------------ */

package Splash;

import Com.FirstSolver.Security.Utils;
import Com.FirstSolver.Splash.FaceIdProtocolCodecFactory;
import java.net.InetSocketAddress;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.service.IoConnector;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

public class FXMLDocumentController extends IoHandlerAdapter implements Initializable {    
    private final String DeviceCharset = "GBK";
    
    @FXML
    private TextField textFieldDeviceIP;
    
    @FXML
    private TextField textFieldDevicePort;
    
    @FXML
    private TextField textFieldSecretKey;
     
    @FXML
    private TextArea textAreaDeviceCommand;
            
    @FXML
    private TextArea textAreaAnswer;

    @FXML
    private void handleButtonExecuteCommand(ActionEvent event) throws Exception {       
        IoConnector TcpClient = new NioSocketConnector();        
        TcpClient.getFilterChain().addLast("codec", new ProtocolCodecFilter(new FaceIdProtocolCodecFactory(DeviceCharset, false, false)));
        TcpClient.setHandler(this);
        
        // 设置读超时等待时间为60秒
        TcpClient.getSessionConfig().setReaderIdleTime(60);
        
        // 建立连接
        ConnectFuture ConnFuture = TcpClient.connect(new InetSocketAddress(textFieldDeviceIP.getText(), Integer.parseInt(textFieldDevicePort.getText())));
        ConnFuture.await();
        
        // 发送查询命令
        if (ConnFuture.isConnected())
        {   // 连接设备成功
            ConnFuture.getSession().write(textAreaDeviceCommand.getText());
            ConnFuture.getSession().getCloseFuture().await();
        }
        else
        {   // 连接设备失败
            Alert alert = new Alert(AlertType.ERROR, "连接设备失败！", ButtonType.OK);
            alert.setTitle("TcpClientDemo");
            alert.setHeaderText("错误");
            alert.showAndWait();
        }
        
        TcpClient.dispose();
    }
    
    @FXML
    private void handleButtonClearAction(ActionEvent event) {
        textAreaAnswer.clear();
    }    
   
    @Override
    public void sessionOpened(IoSession session) throws Exception {
        String SecretKey = textFieldSecretKey.getText();
        if (!Utils.IsNullOrEmpty(SecretKey))
        {   // 设置通信密钥
            FaceIdProtocolCodecFactory.setEncoderKey(session, SecretKey);
            FaceIdProtocolCodecFactory.setDecoderKey(session, SecretKey);
        }
    }
    
    @Override
    public void messageReceived(IoSession session, Object message) throws Exception {
        // 显示消息内容
        textAreaAnswer.setText(message.toString());
        session.closeNow();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
}
