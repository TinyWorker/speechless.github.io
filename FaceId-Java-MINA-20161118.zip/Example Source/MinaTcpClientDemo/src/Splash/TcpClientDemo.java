package Splash;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class TcpClientDemo extends Application {    
    @Override
    public void start(Stage stage) throws Exception {       
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);        
        stage.setScene(scene);
         
        // 设置窗体标题
        stage.setTitle("MinaTcpClientDemo"); 
        
        // 设置窗体图标
        stage.getIcons().add(new Image(getClass().getResourceAsStream("FireEyes.png")));
        
        // 设置到屏幕中心
        stage.centerOnScreen(); 
        
        // 显示窗体
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }    
}
