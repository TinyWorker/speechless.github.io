/* ----------------------------------------------------------
 * 文件名称：FXMLDocumentController.java
 * 
 * 作者：秦建辉
 * 
 * 微信：splashcn
 * 
 * 博客：http://www.firstsolver.com/wordpress/
 * 
 * 开发环境：
 *      NetBeans 8.1
 *      JDK 8u102
 *      
 * 版本历史：
 *      V1.1    2016年08月10日
 *              SDK更新
 *
 *      V1.0    2015年12月10日
 *              验证服务器端
------------------------------------------------------------ */
package Splash;

import Com.FirstSolver.Security.Utils;
import Com.FirstSolver.Splash.FaceIdProtocolCodecFactory;
import Com.FirstSolver.Splash.FaceId_Item;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.AttributeKey;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

public class FXMLDocumentController extends IoHandlerAdapter implements Initializable {
    // 序列号属性键
    private static final AttributeKey KEY_SERIALNUMBER = new AttributeKey(FXMLDocumentController.class, "SerialNumber");
    
    private final String DeviceCharset = "GBK";
    
    private boolean IsServerRunning = false;
    
    public IoAcceptor mTcpServer = null;
 	
    @FXML
    private ComboBox comboBoxServerIP;
    
    @FXML
    private TextField textFieldServerPort;
    
    @FXML
    private TextArea textAreaAnswer;
    
    @FXML
    private Button buttonStartListener;
    
    @FXML
    private CheckBox checkBoxPostPhoto;
    
    @FXML
    private TextArea textAreaDeviceCommand;
    
    @FXML
    private CheckBox checkBoxPassiveEncryption;
    
    @FXML
    private void handleButtonClearAction(ActionEvent event) {
        textAreaAnswer.clear();
    }
    
    @FXML
    private void handleButtonStartListenerAction(ActionEvent event) throws IOException, Exception {
        if(IsServerRunning)
        {
            if(mTcpServer != null)
            {
                mTcpServer.dispose(true);
                mTcpServer = null;
            }
            IsServerRunning = false;
            buttonStartListener.setText("开始侦听");
        }
        else
        {   // 创建侦听服务器
            mTcpServer = new NioSocketAcceptor();
            mTcpServer.getFilterChain().addLast("codec", new ProtocolCodecFilter(new FaceIdProtocolCodecFactory(DeviceCharset, true, checkBoxPassiveEncryption.isSelected())));
            mTcpServer.setHandler(this);
            mTcpServer.bind(new InetSocketAddress(InetAddress.getByName(comboBoxServerIP.getValue().toString()), Integer.parseInt(textFieldServerPort.getText())));
			
            IsServerRunning = true;
            buttonStartListener.setText("停止侦听");
        }
    }
    
    @Override
    public void messageReceived(IoSession session, Object message) throws Exception {
        // 显示消息内容
        String Answer = message.toString();
        textAreaAnswer.appendText(Answer + "\r\n");
        
        if(Answer.startsWith("PostRecord")) {
            // 获取设备序列号
            String SerialNumber = FaceId_Item.GetKeyValue(Answer, "sn");
            session.setAttribute(KEY_SERIALNUMBER, SerialNumber);

            // 服务器回应
            if (checkBoxPostPhoto.isSelected())
            {
                session.write("Return(result=\"success\" postphoto=\"true\")");
            }
            else
            {
                session.write("Return(result=\"success\" postphoto=\"false\")");
            }            
        }
        else if(Answer.startsWith("Record")) {
            // 获取设备序列号
            // String SerialNumber = session.getAttribute(KEY_SERIALNUMBER).toString();

            // 处理卡点数据
            
            // 服务器回应
            session.write("Return(result=\"success\")");
        }
        else if(Answer.startsWith("PostEmployee")) {
            // 准备上传人员信息

            // 服务器回应
            session.write("Return(result=\"success\")");
        }        
        else if(Answer.startsWith("Employee")) {
            // 读取人员信息

            // 服务器回应
            session.write("Return(result=\"success\")");
        }
        else if(Answer.startsWith("GetRequest")) {
            // 处理命令下发
            String Command = textAreaDeviceCommand.getText();
            if (!Utils.IsNullOrEmpty(Command)) 
            {
                session.write(Command); 
                textAreaDeviceCommand.clear();
            }
        }       
        else if(Answer.startsWith("Quit")) {
            // 结束会话
            session.closeNow();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {               
        // 设置服务器地址
        try
        {
            List<String> IPList = new LinkedList<>();
            Enumeration<NetworkInterface> InterfaceList = NetworkInterface.getNetworkInterfaces();
            while (InterfaceList.hasMoreElements())
            { 
                NetworkInterface iFace = InterfaceList.nextElement();
                if(iFace.isLoopback() || iFace.isVirtual() || iFace.isPointToPoint() || !iFace.isUp()) continue;
                                
                Enumeration<InetAddress> AddrList = iFace.getInetAddresses(); 
                while (AddrList.hasMoreElements())
                { 
                    InetAddress address = AddrList.nextElement(); 
                    if (address instanceof Inet4Address)
                    {
                        IPList.add(address.getHostAddress());                
                    }
                } 
            }
            
            if(!IPList.isEmpty()) 
            {
                comboBoxServerIP.setItems(FXCollections.observableList(IPList));
                comboBoxServerIP.getSelectionModel().selectFirst();
            }
        }
        catch (SocketException ex) 
        {
            // 异常处理
        }
    }	
}
